﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BashSoft.Contracts
{
    public interface IDirectoryCreater
    {
        void CreateDirectoryInCurrentFolder(string name);
    }
}
